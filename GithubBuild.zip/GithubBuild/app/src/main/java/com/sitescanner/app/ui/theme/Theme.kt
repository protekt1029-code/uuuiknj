package com.sitescanner.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Dark terminal-style palette — deep slate + acid green accent
val ScannerGreen = Color(0xFF00E676)
val ScannerGreenDim = Color(0xFF1B5E20)
val ScannerRed = Color(0xFFFF5252)
val ScannerOrange = Color(0xFFFFAB40)
val ScannerBlue = Color(0xFF40C4FF)
val ScannerPurple = Color(0xFFB388FF)

val Background = Color(0xFF0D0F14)
val Surface = Color(0xFF151820)
val SurfaceVariant = Color(0xFF1E2230)
val SurfaceBright = Color(0xFF252A3A)
val OnBackground = Color(0xFFE8ECFF)
val OnSurface = Color(0xFFCDD5F5)
val OnSurfaceDim = Color(0xFF7A85A8)
val Outline = Color(0xFF2E3550)

private val DarkColorScheme = darkColorScheme(
    primary = ScannerGreen,
    onPrimary = Color(0xFF003314),
    primaryContainer = ScannerGreenDim,
    onPrimaryContainer = Color(0xFFB9F6CA),
    secondary = ScannerBlue,
    onSecondary = Color(0xFF003A50),
    tertiary = ScannerPurple,
    background = Background,
    surface = Surface,
    surfaceVariant = SurfaceVariant,
    onBackground = OnBackground,
    onSurface = OnSurface,
    onSurfaceVariant = OnSurfaceDim,
    outline = Outline,
    error = ScannerRed,
    onError = Color(0xFF690005),
)

@Composable
fun SiteScannerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = ScannerTypography,
        content = content
    )
}
