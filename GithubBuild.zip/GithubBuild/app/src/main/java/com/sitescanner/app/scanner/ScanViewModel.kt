package com.sitescanner.app.scanner

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sitescanner.app.model.ScanResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ScanViewModel : ViewModel() {

    private val _scanResult = MutableStateFlow(ScanResult())
    val scanResult: StateFlow<ScanResult> = _scanResult

    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput

    fun onUrlChange(url: String) {
        _urlInput.value = url
    }

    fun startScan() {
        val url = _urlInput.value.trim()
        if (url.isEmpty()) return

        _scanResult.value = ScanResult(url = url, isScanning = true, scanProgress = "Initializing...")

        val scanner = SiteScanner { progressMsg ->
            _scanResult.value = _scanResult.value.copy(scanProgress = progressMsg)
        }

        viewModelScope.launch {
            val result = scanner.scan(url)
            _scanResult.value = result
        }
    }

    fun resetScan() {
        _scanResult.value = ScanResult()
        _urlInput.value = ""
    }
}
