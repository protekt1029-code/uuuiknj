package com.sitescanner.app.model

data class ScanResult(
    val url: String = "",
    val finalUrl: String = "",
    val statusCode: Int? = null,
    val reachable: Boolean = false,
    val ipAddress: String = "",
    val isCloudflare: Boolean = false,
    val isPrivateIp: Boolean = false,

    // SSL
    val ssl: SslInfo? = null,

    // Headers
    val securityHeaders: SecurityHeaders = SecurityHeaders(),
    val securityHeaderIssues: List<String> = emptyList(),
    val server: String = "",
    val poweredBy: String = "",

    // WAF
    val wafDetected: List<String> = emptyList(),

    // Technologies
    val technologies: List<String> = emptyList(),

    // Cookies
    val cookieIssues: List<String> = emptyList(),

    // CORS
    val corsFindings: List<String> = emptyList(),

    // HTTP Methods
    val allowedMethods: List<String> = emptyList(),

    // Sensitive paths
    val sensitivePaths: List<SensitivePath> = emptyList(),

    // Content leaks
    val contentLeaks: List<String> = emptyList(),

    // DNS
    val dnsRecords: Map<String, List<String>> = emptyMap(),
    val subdomains: List<String> = emptyList(),
    val dnsConsistency: Map<String, List<String>> = emptyMap(),

    // Ports
    val openPorts: List<Int> = emptyList(),

    // Redirects
    val httpsRedirects: HttpsRedirectInfo = HttpsRedirectInfo(),

    // Robots / Sitemap
    val robots: String = "",
    val sitemap: String = "",

    // Errors & skipped
    val errors: List<String> = emptyList(),
    val skipped: List<String> = emptyList(),

    // Progress tracking
    val scanProgress: String = "",
    val isScanning: Boolean = false,
    val scanComplete: Boolean = false,
)

data class SslInfo(
    val subject: String = "",
    val issuer: String = "",
    val notBefore: String = "",
    val notAfter: String = "",
    val daysLeft: Int = 0,
    val protocol: String = "",
    val cipher: String = "",
    val san: List<String> = emptyList(),
    val expiredWarning: Boolean = false,
    val weakProtocol: Boolean = false,
    val weakCipher: Boolean = false,
)

data class SecurityHeaders(
    val hsts: Boolean = false,
    val csp: Boolean = false,
    val xFrameOptions: String = "Missing",
    val xContentTypeOptions: String = "Missing",
    val referrerPolicy: String = "Missing",
    val permissionsPolicy: String = "Missing",
)

data class SensitivePath(
    val path: String,
    val statusCode: Int,
    val note: String = "",
)

data class HttpsRedirectInfo(
    val httpRedirectsToHttps: Boolean = false,
    val wwwRedirectsToNonWww: Boolean = false,
    val finalUrl: String = "",
)
