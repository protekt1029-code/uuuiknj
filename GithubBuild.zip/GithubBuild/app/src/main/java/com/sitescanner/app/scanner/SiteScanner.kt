package com.sitescanner.app.scanner

import android.util.Log
import com.sitescanner.app.model.*
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.tls.HandshakeCertificates
import java.io.IOException
import java.net.*
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.*
import kotlin.math.*

private val TAG = "SiteScanner"

private val CLOUDFLARE_PREFIXES = listOf(
    "104.16.", "104.17.", "104.18.", "104.19.", "104.20.", "104.21.", "104.22.",
    "172.64.", "172.65.", "172.66.", "172.67.",
    "188.114.", "190.93.", "141.101.", "108.162.", "173.245."
)

private val SENSITIVE_PATHS = listOf(
    "/.env", "/.git/HEAD", "/.git/config", "/config.php.bak", "/config.json",
    "/backup.sql", "/db.sqlite", "/phpinfo.php", "/.ds_store", "/server-status",
    "/api/v1", "/api/v2", "/swagger.json", "/openapi.json", "/actuator/health",
    "/console", "/wp-config.php.bak", "/docker-compose.yml",
    "/admin", "/manager", "/cpanel", "/webmail", "/phpmyadmin", "/wp-admin",
    "/.aws/credentials", "/.ssh/id_rsa", "/.bash_history",
    "/.htaccess", "/.gitignore", "/robots.txt", "/sitemap.xml",
    "/.well-known/security.txt", "/readme.html"
)

private val COMMON_SUBDOMAINS = listOf(
    "admin", "mail", "ftp", "cpanel", "direct", "dev", "test",
    "backup", "staging", "api", "app", "beta", "shop", "blog",
    "dashboard", "console", "manage", "portal", "cdn", "media",
    "static", "assets", "secure", "auth", "www2", "www3"
)

private val COMMON_PORTS = listOf(21, 22, 80, 443, 3306, 3389, 5432, 6379, 8080, 8443, 8000, 9200)

private val WAF_HEADERS = mapOf(
    "cf-ray" to "Cloudflare", "cf-cache-status" to "Cloudflare",
    "x-sucuri-id" to "Sucuri", "x-sucuri-cache" to "Sucuri",
    "x-akamai-transformed" to "Akamai", "x-akamai-request-id" to "Akamai",
    "x-iinfo" to "Incapsula/Imperva", "x-amzn-waf-action" to "AWS WAF",
    "x-amz-cf-id" to "AWS CloudFront", "x-modsecurity" to "ModSecurity",
    "x-fw-hash" to "Fastly WAF", "x-fastly-request-id" to "Fastly",
    "x-datadome" to "DataDome", "x-wallarm-node" to "Wallarm"
)

private val TECH_HEADERS = mapOf(
    "x-powered-by" to "X-Powered-By", "server" to "Server",
    "x-aspnet-version" to "ASP.NET", "x-django-version" to "Django",
    "x-runtime" to "Ruby on Rails", "x-vercel-id" to "Vercel",
    "x-netlify" to "Netlify", "x-github-request-id" to "GitHub Pages"
)

private val TECH_SERVER_KEYWORDS = mapOf(
    "nginx" to "Nginx", "apache" to "Apache", "iis" to "IIS",
    "litespeed" to "LiteSpeed", "gunicorn" to "Gunicorn",
    "cloudflare" to "Cloudflare", "varnish" to "Varnish",
    "caddy" to "Caddy", "openresty" to "OpenResty"
)

private val TECH_POWERED_KEYWORDS = mapOf(
    "php" to "PHP", "asp.net" to "ASP.NET", "express" to "Express.js",
    "next.js" to "Next.js", "laravel" to "Laravel"
)

private val API_KEY_PATTERNS = listOf(
    Pair("AWS Key", Regex("AKIA[0-9A-Z]{16}")),
    Pair("Google API Key", Regex("AIza[0-9A-Za-z\\-_]{35}")),
    Pair("Stripe Secret", Regex("sk_live_[0-9a-zA-Z]{24,}")),
    Pair("GitHub Token", Regex("ghp_[0-9a-zA-Z]{36}")),
    Pair("Slack Token", Regex("xox[baprs]-[0-9a-zA-Z\\-]{10,}")),
    Pair("Private Key", Regex("-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    Pair("Generic API Key", Regex("(?i)(?:api[_-]?key|apikey|token)[\"']?\\s*[:=]\\s*[\"']([a-zA-Z0-9\\-_]{20,80})"))
)

private val EMAIL_RE = Regex("[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}")

private fun isPrivateIp(ip: String): Boolean {
    return try {
        val addr = InetAddress.getByName(ip)
        addr.isSiteLocalAddress || addr.isLoopbackAddress || addr.isLinkLocalAddress
    } catch (e: Exception) { false }
}

private fun isCloudflareIp(ip: String): Boolean =
    CLOUDFLARE_PREFIXES.any { ip.startsWith(it) }

class SiteScanner(private val onProgress: (String) -> Unit) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .hostnameVerifier { _, _ -> true }
        .sslSocketFactory(createTrustAllSslContext().socketFactory, TrustAllX509TrustManager())
        .build()

    private val noRedirectClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .followRedirects(false)
        .followSslRedirects(false)
        .hostnameVerifier { _, _ -> true }
        .sslSocketFactory(createTrustAllSslContext().socketFactory, TrustAllX509TrustManager())
        .build()

    private fun createTrustAllSslContext(): SSLContext {
        val context = SSLContext.getInstance("TLS")
        context.init(null, arrayOf(TrustAllX509TrustManager()), null)
        return context
    }

    suspend fun scan(inputUrl: String): ScanResult = withContext(Dispatchers.IO) {
        val url = normalizeUrl(inputUrl)
        var result = ScanResult(url = url, isScanning = true)

        try {
            // 1. Resolve host
            progress("Resolving host...")
            val host = extractHost(url)
            val ip = withTimeoutOrNull(5000L) {
                try { InetAddress.getByName(host)?.hostAddress ?: "" }
                catch (e: Exception) { "" }
            } ?: ""

            val isPrivate = ip.isNotEmpty() && isPrivateIp(ip)
            val isCF = ip.isNotEmpty() && isCloudflareIp(ip)

            result = result.copy(ipAddress = ip, isPrivateIp = isPrivate, isCloudflare = isCF)

            // 2. Main request
            progress("Connecting to site...")
            val mainResponse = safeGet(url)
            val statusCode = mainResponse?.code
            val reachable = statusCode != null && statusCode in 100..599
            val responseBody = mainResponse?.body?.string() ?: ""
            val headers = mainResponse?.headers

            result = result.copy(
                finalUrl = mainResponse?.request?.url?.toString() ?: url,
                statusCode = statusCode,
                reachable = reachable,
                server = headers?.get("Server") ?: "",
                poweredBy = headers?.get("X-Powered-By") ?: ""
            )

            // 3. SSL check
            progress("Checking SSL certificate...")
            val ssl = if (url.startsWith("https://")) checkSsl(host) else null
            result = result.copy(ssl = ssl)

            // 4. Security headers
            progress("Analyzing security headers...")
            val secHeaders = analyzeSecurityHeaders(headers)
            val headerIssues = checkSecurityHeaderIssues(headers)
            result = result.copy(
                securityHeaders = secHeaders,
                securityHeaderIssues = headerIssues
            )

            // 5. WAF detection
            progress("Detecting WAF/CDN...")
            val waf = detectWaf(headers, responseBody, statusCode ?: 0)
            result = result.copy(wafDetected = waf)

            // 6. Technology detection
            progress("Detecting technologies...")
            val techs = detectTechnologies(headers, responseBody)
            result = result.copy(technologies = techs)

            // 7. Cookie analysis
            progress("Analyzing cookies...")
            val cookieIssues = analyzeCookies(headers)
            result = result.copy(cookieIssues = cookieIssues)

            // 8. Content leaks
            progress("Scanning for secrets & leaks...")
            val leaks = analyzeLeaks(responseBody)
            result = result.copy(contentLeaks = leaks)

            // 9. HTTPS redirect check
            progress("Checking HTTPS redirects...")
            val redirectInfo = checkHttpsRedirects(host, url)
            result = result.copy(httpsRedirects = redirectInfo)

            // 10. HTTP methods
            progress("Checking HTTP methods...")
            val methods = checkHttpMethods(url)
            result = result.copy(allowedMethods = methods)

            // 11. DNS records
            progress("Fetching DNS records...")
            val dnsRecords = getDnsRecords(host)
            result = result.copy(dnsRecords = dnsRecords)

            // 12. DNS consistency
            progress("Checking DNS consistency...")
            val dnsConsistency = checkDnsConsistency(host)
            result = result.copy(dnsConsistency = dnsConsistency)

            // 13. Subdomain enumeration
            progress("Enumerating subdomains...")
            val subdomains = bruteSubdomains(host)
            result = result.copy(subdomains = subdomains)

            // 14. Port scanning
            progress("Scanning common ports...")
            val openPorts = scanPorts(ip.ifEmpty { host })
            result = result.copy(openPorts = openPorts)

            // 15. Sensitive path discovery
            progress("Probing sensitive paths...")
            val sensitivePaths = probeSensitivePaths(url)
            result = result.copy(sensitivePaths = sensitivePaths)

            // 16. CORS check
            progress("Checking CORS policy...")
            val cors = checkCors(url, host)
            result = result.copy(corsFindings = cors)

            // 17. Robots & Sitemap
            progress("Checking robots.txt and sitemap...")
            val robots = checkPath(url, "/robots.txt")
            val sitemap = checkPath(url, "/sitemap.xml")
            result = result.copy(robots = robots, sitemap = sitemap)

            progress("Scan complete!")
            result.copy(isScanning = false, scanComplete = true)

        } catch (e: Exception) {
            Log.e(TAG, "Scan error", e)
            result.copy(
                isScanning = false,
                scanComplete = true,
                errors = result.errors + "Scan error: ${e.message}"
            )
        }
    }

    // ---- Helper functions ----

    private fun normalizeUrl(input: String): String {
        val trimmed = input.trim()
        return if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) trimmed
        else "https://$trimmed"
    }

    private fun extractHost(url: String): String {
        return try { URL(url).host } catch (e: Exception) { url }
    }

    private fun progress(msg: String) {
        onProgress(msg)
    }

    private fun safeGet(url: String, extraHeaders: Map<String, String> = emptyMap()): Response? {
        return try {
            val reqBuilder = Request.Builder().url(url).get()
            extraHeaders.forEach { (k, v) -> reqBuilder.addHeader(k, v) }
            client.newCall(reqBuilder.build()).execute()
        } catch (e: Exception) { null }
    }

    private fun safeRequest(method: String, url: String, headers: Map<String, String> = emptyMap()): Response? {
        return try {
            val reqBuilder = Request.Builder().url(url)
            headers.forEach { (k, v) -> reqBuilder.addHeader(k, v) }
            when (method.uppercase()) {
                "HEAD" -> reqBuilder.head()
                "OPTIONS" -> reqBuilder.method("OPTIONS", null)
                "PUT" -> reqBuilder.put(RequestBody.create(null, byteArrayOf()))
                "DELETE" -> reqBuilder.delete()
                "PATCH" -> reqBuilder.patch(RequestBody.create(null, byteArrayOf()))
                else -> reqBuilder.get()
            }
            client.newCall(reqBuilder.build()).execute()
        } catch (e: Exception) { null }
    }

    private fun checkSsl(host: String): SslInfo? {
        return try {
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf(TrustAllX509TrustManager()), null)
            val factory = ctx.socketFactory
            val socket = factory.createSocket(host, 443) as SSLSocket
            socket.startHandshake()
            val session = socket.session
            val certs = session.peerCertificates
            val cert = certs.firstOrNull() as? X509Certificate
            val info = SslInfo(
                subject = cert?.subjectDN?.name ?: "",
                issuer = cert?.issuerDN?.name ?: "",
                notBefore = cert?.notBefore?.toString() ?: "",
                notAfter = cert?.notAfter?.toString() ?: "",
                daysLeft = cert?.let {
                    ((it.notAfter.time - System.currentTimeMillis()) / 86400000).toInt()
                } ?: 0,
                protocol = session.protocol,
                cipher = session.cipherSuite,
                san = extractSan(cert),
                expiredWarning = cert?.let {
                    ((it.notAfter.time - System.currentTimeMillis()) / 86400000) < 14
                } ?: false,
                weakProtocol = session.protocol in listOf("TLSv1", "TLSv1.1", "SSLv3"),
                weakCipher = session.cipherSuite.contains("RC4") || session.cipherSuite.contains("3DES")
            )
            socket.close()
            info
        } catch (e: Exception) { null }
    }

    private fun extractSan(cert: X509Certificate?): List<String> {
        if (cert == null) return emptyList()
        return try {
            cert.subjectAlternativeNames?.mapNotNull { san ->
                if (san[0] == 2) san[1] as? String else null
            } ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }

    private fun analyzeSecurityHeaders(headers: Headers?): SecurityHeaders {
        if (headers == null) return SecurityHeaders()
        val lh = headers.toMap().mapKeys { it.key.lowercase() }
        return SecurityHeaders(
            hsts = lh.containsKey("strict-transport-security"),
            csp = lh.containsKey("content-security-policy"),
            xFrameOptions = lh["x-frame-options"] ?: "Missing",
            xContentTypeOptions = lh["x-content-type-options"] ?: "Missing",
            referrerPolicy = lh["referrer-policy"] ?: "Missing",
            permissionsPolicy = lh["permissions-policy"] ?: "Missing"
        )
    }

    private fun checkSecurityHeaderIssues(headers: Headers?): List<String> {
        val issues = mutableListOf<String>()
        if (headers == null) {
            issues.add("Could not retrieve headers")
            return issues
        }
        val lh = headers.toMap().mapKeys { it.key.lowercase() }

        val hsts = lh["strict-transport-security"]
        if (hsts != null) {
            if ("includesubdomains" !in hsts.lowercase()) issues.add("HSTS missing includeSubDomains")
            if ("preload" !in hsts.lowercase()) issues.add("HSTS missing preload")
        } else {
            issues.add("HSTS header missing")
        }

        val csp = lh["content-security-policy"]
        if (csp != null) {
            if ("'unsafe-inline'" in csp.lowercase()) issues.add("CSP has unsafe-inline")
            if ("'unsafe-eval'" in csp.lowercase()) issues.add("CSP has unsafe-eval")
            if ("frame-ancestors" !in csp.lowercase()) issues.add("CSP missing frame-ancestors")
        } else {
            issues.add("CSP header missing")
        }

        if (!lh.containsKey("x-frame-options")) issues.add("X-Frame-Options missing (clickjacking risk)")
        if (lh["x-content-type-options"]?.lowercase()?.trim() != "nosniff")
            issues.add("X-Content-Type-Options not set to nosniff")
        if (!lh.containsKey("referrer-policy")) issues.add("Referrer-Policy missing")
        if (!lh.containsKey("permissions-policy")) issues.add("Permissions-Policy missing")

        return issues
    }

    private fun detectWaf(headers: Headers?, html: String, status: Int): List<String> {
        val found = mutableSetOf<String>()
        val lh = headers?.toMap()?.mapKeys { it.key.lowercase() } ?: emptyMap()

        WAF_HEADERS.forEach { (header, name) ->
            if (lh.containsKey(header)) found.add(name)
        }

        val server = lh["server"]?.lowercase() ?: ""
        if ("cloudflare" in server) found.add("Cloudflare")
        if ("akamai" in server) found.add("Akamai")
        if ("sucuri" in server) found.add("Sucuri")
        if ("incapsula" in server) found.add("Incapsula")
        if ("modsecurity" in server) found.add("ModSecurity")

        if (status in listOf(403, 406, 429, 503)) {
            val lower = html.lowercase()
            if ("cloudflare" in lower) found.add("Cloudflare")
            if ("sucuri website firewall" in lower) found.add("Sucuri")
            if ("incapsula" in lower) found.add("Incapsula")
            if ("mod_security" in lower || "modsecurity" in lower) found.add("ModSecurity")
            if ("big-ip" in lower) found.add("F5 BIG-IP")
        }

        return if (found.isEmpty()) listOf("No WAF detected") else found.toList()
    }

    private fun detectTechnologies(headers: Headers?, html: String): List<String> {
        val techs = mutableSetOf<String>()
        val lh = headers?.toMap()?.mapKeys { it.key.lowercase() } ?: emptyMap()

        val server = lh["server"]?.lowercase() ?: ""
        TECH_SERVER_KEYWORDS.forEach { (k, v) -> if (k in server) techs.add(v) }

        val powered = lh["x-powered-by"]?.lowercase() ?: ""
        TECH_POWERED_KEYWORDS.forEach { (k, v) -> if (k in powered) techs.add(v) }

        if (lh.containsKey("x-aspnet-version")) techs.add("ASP.NET")
        if (lh.containsKey("x-django-version")) techs.add("Django")
        if (lh.containsKey("x-runtime")) techs.add("Ruby on Rails")
        if (lh.containsKey("x-vercel-id")) techs.add("Vercel")
        if (lh.containsKey("x-netlify")) techs.add("Netlify")
        if (lh.containsKey("x-github-request-id")) techs.add("GitHub Pages")
        if (lh.containsKey("x-drupal-cache")) techs.add("Drupal")
        if (lh.containsKey("x-shopify-stage")) techs.add("Shopify")

        if (html.isNotEmpty()) {
            val lower = html.lowercase()
            val pathMap = mapOf(
                "wp-content" to "WordPress", "wp-includes" to "WordPress",
                "_next/static" to "Next.js", "/_nuxt/" to "Nuxt.js",
                "react-dom" to "React", "vue.min" to "Vue.js",
                "angular" to "Angular", "jquery" to "jQuery",
                "bootstrap.min" to "Bootstrap", "tailwind" to "Tailwind CSS",
                "gatsby" to "Gatsby", "/_astro/" to "Astro",
                "shopify" to "Shopify", "recaptcha" to "Google reCAPTCHA",
                "googletagmanager" to "Google Tag Manager",
                "fonts.googleapis" to "Google Fonts",
                "hotjar" to "Hotjar", "intercom" to "Intercom",
                "csrfmiddlewaretoken" to "Django", "laravel" to "Laravel"
            )
            pathMap.forEach { (k, v) -> if (k in lower) techs.add(v) }

            val domMarkers = mapOf(
                "data-reactroot" to "React", "ng-version" to "Angular",
                "__next_data__" to "Next.js", "__nuxt" to "Nuxt.js",
                "shopify-section" to "Shopify", "w-nav" to "Webflow"
            )
            domMarkers.forEach { (k, v) -> if (k in lower) techs.add(v) }

            val genMatch = Regex("""<meta[^>]*name=["']?generator["']?[^>]*content=["']([^"']+)["']""", RegexOption.IGNORE_CASE).find(html)
            genMatch?.groupValues?.getOrNull(1)?.let { techs.add("Generator: $it") }
        }

        return techs.sorted()
    }

    private fun analyzeCookies(headers: Headers?): List<String> {
        if (headers == null) return emptyList()
        val issues = mutableSetOf<String>()
        headers.values("Set-Cookie").forEach { cookie ->
            val lower = cookie.lowercase()
            if ("httponly" !in lower) issues.add("Cookie missing HttpOnly flag")
            if ("secure" !in lower) issues.add("Cookie missing Secure flag")
            if ("samesite" !in lower) issues.add("Cookie missing SameSite attribute")
            if ("samesite=none" in lower && "secure" !in lower)
                issues.add("Cookie: SameSite=None without Secure")
        }
        return issues.toList()
    }

    private fun analyzeLeaks(html: String): List<String> {
        val leaks = mutableListOf<String>()
        if (html.isEmpty()) return leaks

        val emails = EMAIL_RE.findAll(html)
            .map { it.value }
            .filter { !it.contains("example.com") && !it.contains("@sentry") }
            .take(5).toList()
        if (emails.isNotEmpty()) leaks.add("Emails: ${emails.joinToString(", ")}")

        API_KEY_PATTERNS.forEach { (name, pattern) ->
            if (pattern.containsMatchIn(html)) leaks.add("Possible $name found in source")
        }

        val ipRe = Regex("""\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b""")
        val publicIps = ipRe.findAll(html)
            .map { it.value }
            .filter { ip -> !isPrivateIp(ip) }
            .take(3).toList()
        if (publicIps.isNotEmpty()) leaks.add("Public IPs in source: ${publicIps.joinToString(", ")}")

        val todos = Regex("""<!--\s*TODO:.*?-->""", RegexOption.DOT_MATCHES_ALL).findAll(html).count()
        if (todos > 0) leaks.add("TODO comments in HTML: $todos")

        return leaks
    }

    private suspend fun checkHttpsRedirects(host: String, originalUrl: String): HttpsRedirectInfo {
        return try {
            val httpUrl = "http://$host"
            val resp = withTimeoutOrNull(8000L) {
                try {
                    val req = Request.Builder().url(httpUrl).get().build()
                    noRedirectClient.newCall(req).execute()
                } catch (e: Exception) { null }
            }
            val redirectsToHttps = resp?.let {
                val loc = it.header("Location") ?: ""
                it.code in listOf(301, 302, 307, 308) && loc.startsWith("https://")
            } ?: false

            HttpsRedirectInfo(
                httpRedirectsToHttps = redirectsToHttps,
                finalUrl = originalUrl
            )
        } catch (e: Exception) {
            HttpsRedirectInfo()
        }
    }

    private suspend fun checkHttpMethods(url: String): List<String> {
        val methods = mutableListOf<String>()
        val toTest = listOf("GET", "HEAD", "OPTIONS", "PUT", "DELETE", "PATCH", "TRACE")
        toTest.forEach { method ->
            try {
                val resp = withTimeoutOrNull(6000L) { safeRequest(method, url) }
                if (resp != null && resp.code !in listOf(405, 501)) {
                    methods.add("$method (${resp.code})")
                }
            } catch (e: Exception) {}
        }
        return methods
    }

    private suspend fun getDnsRecords(host: String): Map<String, List<String>> {
        val records = mutableMapOf<String, List<String>>()
        return withContext(Dispatchers.IO) {
            try {
                val addr = InetAddress.getAllByName(host)
                records["A"] = addr.filter { it is Inet4Address }.map { it.hostAddress ?: "" }
                records["AAAA"] = addr.filter { it is Inet6Address }.map { it.hostAddress ?: "" }
            } catch (e: Exception) {}
            records
        }
    }

    private suspend fun checkDnsConsistency(host: String): Map<String, List<String>> {
        val dnsServers = listOf("8.8.8.8", "1.1.1.1", "9.9.9.9")
        val results = mutableMapOf<String, List<String>>()
        dnsServers.forEach { dns ->
            try {
                withTimeoutOrNull(4000L) {
                    val ips = InetAddress.getAllByName(host)
                        .map { it.hostAddress ?: "" }
                        .filter { it.isNotEmpty() }
                    results[dns] = ips
                }
            } catch (e: Exception) {
                results[dns] = listOf("error")
            }
        }
        return results
    }

    private suspend fun bruteSubdomains(domain: String): List<String> {
        val found = mutableListOf<String>()
        val sem = kotlinx.coroutines.sync.Semaphore(10)
        coroutineScope {
            COMMON_SUBDOMAINS.map { sub ->
                async {
                    sem.withPermit {
                        try {
                            val fqdn = "$sub.$domain"
                            withTimeoutOrNull(3000L) {
                                val ip = InetAddress.getByName(fqdn)?.hostAddress
                                if (ip != null) synchronized(found) { found.add("$fqdn → $ip") }
                            }
                        } catch (e: Exception) {}
                    }
                }
            }.awaitAll()
        }
        return found.sorted()
    }

    private suspend fun scanPorts(host: String): List<Int> {
        val open = mutableListOf<Int>()
        val sem = kotlinx.coroutines.sync.Semaphore(8)
        coroutineScope {
            COMMON_PORTS.map { port ->
                async {
                    sem.withPermit {
                        try {
                            withTimeoutOrNull(2000L) {
                                val socket = Socket()
                                socket.connect(InetSocketAddress(host, port), 1500)
                                socket.close()
                                synchronized(open) { open.add(port) }
                            }
                        } catch (e: Exception) {}
                    }
                }
            }.awaitAll()
        }
        return open.sorted()
    }

    private suspend fun probeSensitivePaths(baseUrl: String): List<SensitivePath> {
        val found = mutableListOf<SensitivePath>()
        val sem = kotlinx.coroutines.sync.Semaphore(5)
        coroutineScope {
            SENSITIVE_PATHS.map { path ->
                async {
                    sem.withPermit {
                        try {
                            val url = baseUrl.trimEnd('/') + path
                            withTimeoutOrNull(6000L) {
                                val resp = safeGet(url)
                                if (resp != null && resp.code !in listOf(404, 410)) {
                                    val note = when (resp.code) {
                                        200 -> "⚠ EXPOSED"
                                        401 -> "Auth required"
                                        403 -> "Forbidden (exists)"
                                        301, 302 -> "Redirect → ${resp.header("Location")}"
                                        else -> "HTTP ${resp.code}"
                                    }
                                    synchronized(found) {
                                        found.add(SensitivePath(path, resp.code, note))
                                    }
                                }
                            }
                        } catch (e: Exception) {}
                    }
                }
            }.awaitAll()
        }
        return found.sortedBy { it.path }
    }

    private suspend fun checkCors(url: String, host: String): List<String> {
        val findings = mutableListOf<String>()
        val originsToTest = listOf("https://evil.com", "null", "https://sub.$host")
        originsToTest.forEach { origin ->
            try {
                val resp = withTimeoutOrNull(6000L) {
                    safeRequest("OPTIONS", url, mapOf("Origin" to origin))
                } ?: return@forEach
                val acao = resp.header("Access-Control-Allow-Origin")
                val acac = resp.header("Access-Control-Allow-Credentials")
                if (acao != null) {
                    when {
                        acao == "*" -> findings.add("CORS: wildcard '*' for origin '$origin'")
                        acao == origin -> findings.add("CORS: origin '$origin' reflected")
                        else -> findings.add("CORS: ACAO='$acao' for '$origin'")
                    }
                    if (acac?.lowercase() == "true")
                        findings.add("CORS: credentials allowed for '$origin'")
                }
            } catch (e: Exception) {}
        }
        return if (findings.isEmpty()) listOf("No permissive CORS found") else findings
    }

    private fun checkPath(baseUrl: String, path: String): String {
        return try {
            val url = baseUrl.trimEnd('/') + path
            val resp = safeGet(url)
            when (resp?.code) {
                200 -> "Found"
                404 -> "Not found"
                403 -> "Forbidden (exists)"
                null -> "Error"
                else -> "HTTP ${resp.code}"
            }
        } catch (e: Exception) { "Error" }
    }

    private class TrustAllX509TrustManager : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
    }
}

private fun Headers.toMap(): Map<String, String> {
    val map = mutableMapOf<String, String>()
    for (i in 0 until size) map[name(i)] = value(i)
    return map
}
