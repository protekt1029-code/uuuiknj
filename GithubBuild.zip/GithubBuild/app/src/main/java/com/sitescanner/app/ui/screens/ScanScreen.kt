package com.sitescanner.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sitescanner.app.model.*
import com.sitescanner.app.scanner.ScanViewModel
import com.sitescanner.app.ui.theme.*

@Composable
fun ScanScreen(viewModel: ScanViewModel, modifier: Modifier = Modifier) {
    val result by viewModel.scanResult.collectAsState()
    val urlInput by viewModel.urlInput.collectAsState()
    val focusManager = LocalFocusManager.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Background)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            item {
                HeaderSection()
            }
            item {
                InputSection(
                    url = urlInput,
                    onUrlChange = viewModel::onUrlChange,
                    onScan = {
                        focusManager.clearFocus()
                        viewModel.startScan()
                    },
                    onReset = viewModel::resetScan,
                    isScanning = result.isScanning
                )
            }
            if (result.isScanning) {
                item { ProgressSection(result.scanProgress) }
            }
            if (result.scanComplete) {
                item { OverviewCard(result) }
                item { SslCard(result.ssl) }
                item { SecurityHeadersCard(result.securityHeaders, result.securityHeaderIssues) }
                item { WafCard(result.wafDetected) }
                item { TechCard(result.technologies) }
                if (result.contentLeaks.isNotEmpty()) {
                    item { LeaksCard(result.contentLeaks) }
                }
                item { SensitivePathsCard(result.sensitivePaths) }
                item { CorsCard(result.corsFindings) }
                item { CookiesCard(result.cookieIssues) }
                item { HttpMethodsCard(result.allowedMethods) }
                item { DnsCard(result.dnsRecords, result.dnsConsistency) }
                if (result.subdomains.isNotEmpty()) {
                    item { SubdomainsCard(result.subdomains) }
                }
                if (result.openPorts.isNotEmpty()) {
                    item { PortsCard(result.openPorts) }
                }
                item { MiscCard(result) }
                if (result.errors.isNotEmpty()) {
                    item { ErrorsCard(result.errors) }
                }
            }
        }
    }
}

@Composable
fun HeaderSection() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Surface)
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Security,
                    contentDescription = null,
                    tint = ScannerGreen,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "SITE SCANNER",
                    style = MaterialTheme.typography.displayLarge.copy(
                        color = ScannerGreen,
                        fontSize = 22.sp,
                        letterSpacing = 3.sp
                    )
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Security analysis tool",
                style = MaterialTheme.typography.bodySmall,
                color = OnSurfaceDim
            )
        }
    }
    Divider(color = Outline, thickness = 1.dp)
}

@Composable
fun InputSection(
    url: String,
    onUrlChange: (String) -> Unit,
    onScan: () -> Unit,
    onReset: () -> Unit,
    isScanning: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Surface)
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = url,
            onValueChange = onUrlChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = {
                Text(
                    "https://example.com",
                    style = MaterialTheme.typography.bodyMedium,
                    color = OnSurfaceDim
                )
            },
            leadingIcon = {
                Icon(Icons.Default.Language, null, tint = ScannerGreen)
            },
            singleLine = true,
            enabled = !isScanning,
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Uri,
                imeAction = ImeAction.Go
            ),
            keyboardActions = KeyboardActions(onGo = { onScan() }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ScannerGreen,
                unfocusedBorderColor = Outline,
                focusedTextColor = OnBackground,
                unfocusedTextColor = OnBackground,
                cursorColor = ScannerGreen,
                focusedContainerColor = SurfaceVariant,
                unfocusedContainerColor = SurfaceVariant
            ),
            shape = RoundedCornerShape(8.dp),
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace)
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = onScan,
                enabled = !isScanning && url.isNotBlank(),
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = ScannerGreen,
                    contentColor = Color(0xFF003314),
                    disabledContainerColor = ScannerGreenDim,
                    disabledContentColor = OnSurfaceDim
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                if (isScanning) {
                    val rotation by rememberInfiniteTransition(label = "spin").animateFloat(
                        initialValue = 0f, targetValue = 360f,
                        animationSpec = infiniteRepeatable(tween(1000)), label = "rot"
                    )
                    Icon(Icons.Default.Refresh, null,
                        modifier = Modifier.graphicsLayer { rotationZ = rotation })
                    Spacer(Modifier.width(6.dp))
                    Text("SCANNING...", fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.Search, null)
                    Spacer(Modifier.width(6.dp))
                    Text("SCAN", fontWeight = FontWeight.Bold)
                }
            }
            if (!isScanning) {
                OutlinedButton(
                    onClick = onReset,
                    colors = OutlinedButtonDefaults.outlinedButtonColors(contentColor = OnSurfaceDim),
                    border = BorderStroke(1.dp, Outline),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Clear, null, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
    Divider(color = Outline, thickness = 1.dp)
}

@Composable
fun ProgressSection(progress: String) {
    val alpha by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0.5f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "alpha"
    )
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceVariant),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color = ScannerGreen,
                strokeWidth = 2.dp
            )
            Spacer(Modifier.width(12.dp))
            Text(
                progress,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    color = ScannerGreen.copy(alpha = alpha)
                )
            )
        }
    }
}

// ---- Result Cards ----

@Composable
fun SectionCard(
    title: String,
    icon: ImageVector,
    iconTint: Color = ScannerGreen,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceVariant),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = iconTint, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    title,
                    style = MaterialTheme.typography.titleMedium,
                    color = OnBackground
                )
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun StatusBadge(text: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = color)
    }
}

@Composable
fun InfoRow(label: String, value: String, valueColor: Color = OnSurface) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = OnSurfaceDim,
            modifier = Modifier.weight(0.4f)
        )
        Text(
            value.ifEmpty { "—" },
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            color = valueColor,
            modifier = Modifier.weight(0.6f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun OverviewCard(result: ScanResult) {
    SectionCard("Overview", Icons.Default.Info) {
        val statusColor = when {
            result.statusCode in 200..299 -> ScannerGreen
            result.statusCode in 300..399 -> ScannerOrange
            result.statusCode != null -> ScannerRed
            else -> OnSurfaceDim
        }
        InfoRow("URL", result.url)
        InfoRow("Status", result.statusCode?.toString() ?: "unreachable", statusColor)
        InfoRow("IP", result.ipAddress)
        if (result.isCloudflare) InfoRow("CDN", "Cloudflare", ScannerOrange)
        if (result.isPrivateIp) InfoRow("IP Type", "Private", ScannerOrange)
        if (result.server.isNotEmpty()) InfoRow("Server", result.server)
        if (result.poweredBy.isNotEmpty()) InfoRow("X-Powered-By", result.poweredBy)
        InfoRow("HTTPS redirect", if (result.httpsRedirects.httpRedirectsToHttps) "✓ Yes" else "✗ No",
            if (result.httpsRedirects.httpRedirectsToHttps) ScannerGreen else ScannerRed)
    }
}

@Composable
fun SslCard(ssl: SslInfo?) {
    SectionCard("SSL Certificate", Icons.Default.Lock,
        iconTint = if (ssl != null && !ssl.expiredWarning && !ssl.weakProtocol) ScannerGreen else ScannerRed
    ) {
        if (ssl == null) {
            Text("No SSL or could not retrieve certificate", color = ScannerRed,
                style = MaterialTheme.typography.bodyMedium)
            return@SectionCard
        }
        InfoRow("Issuer", ssl.issuer.substringAfterLast("O=").substringBefore(",").trim())
        InfoRow("Expires", ssl.notAfter)
        InfoRow("Days left", ssl.daysLeft.toString(),
            if (ssl.daysLeft > 30) ScannerGreen else if (ssl.daysLeft > 7) ScannerOrange else ScannerRed)
        InfoRow("Protocol", ssl.protocol,
            if (ssl.weakProtocol) ScannerRed else ScannerGreen)
        InfoRow("Cipher", ssl.cipher)
        if (ssl.san.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text("SAN domains:", style = MaterialTheme.typography.bodySmall, color = OnSurfaceDim)
            ssl.san.take(6).forEach { domain ->
                Text(" · $domain", style = MaterialTheme.typography.bodySmall,
                    color = OnSurface, fontFamily = FontFamily.Monospace)
            }
            if (ssl.san.size > 6) Text(" · +${ssl.san.size - 6} more",
                style = MaterialTheme.typography.bodySmall, color = OnSurfaceDim)
        }
        if (ssl.expiredWarning) {
            Spacer(Modifier.height(6.dp))
            StatusBadge("⚠ EXPIRES SOON", ScannerOrange)
        }
        if (ssl.weakProtocol) {
            Spacer(Modifier.height(4.dp))
            StatusBadge("⚠ WEAK PROTOCOL: ${ssl.protocol}", ScannerRed)
        }
    }
}

@Composable
fun SecurityHeadersCard(headers: SecurityHeaders, issues: List<String>) {
    SectionCard("Security Headers", Icons.Default.Shield,
        iconTint = if (issues.isEmpty()) ScannerGreen else ScannerOrange
    ) {
        val rows = listOf(
            "HSTS" to (if (headers.hsts) "✓ Present" else "✗ Missing") to if (headers.hsts) ScannerGreen else ScannerRed,
            "CSP" to (if (headers.csp) "✓ Present" else "✗ Missing") to if (headers.csp) ScannerGreen else ScannerRed,
            "X-Frame-Options" to headers.xFrameOptions to if (headers.xFrameOptions == "Missing") ScannerRed else ScannerGreen,
            "X-Content-Type" to headers.xContentTypeOptions to if (headers.xContentTypeOptions == "Missing") ScannerRed else ScannerGreen,
            "Referrer-Policy" to headers.referrerPolicy to if (headers.referrerPolicy == "Missing") ScannerOrange else ScannerGreen,
            "Permissions-Policy" to headers.permissionsPolicy to if (headers.permissionsPolicy == "Missing") ScannerOrange else ScannerGreen,
        )
        rows.forEach { (pair, color) ->
            val (label, value) = pair
            InfoRow(label, value, color)
        }
        if (issues.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Divider(color = Outline)
            Spacer(Modifier.height(8.dp))
            Text("Issues:", style = MaterialTheme.typography.bodySmall, color = OnSurfaceDim)
            issues.forEach { issue ->
                Text(" · $issue", style = MaterialTheme.typography.bodySmall, color = ScannerOrange)
            }
        }
    }
}

@Composable
fun WafCard(waf: List<String>) {
    val isProtected = waf.firstOrNull() != "No WAF detected"
    SectionCard("WAF / CDN", Icons.Default.Fireplace, iconTint = if (isProtected) ScannerGreen else OnSurfaceDim) {
        if (!isProtected) {
            Text("No WAF/CDN detected", color = OnSurfaceDim, style = MaterialTheme.typography.bodyMedium)
        } else {
            waf.forEach { w ->
                Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(ScannerGreen)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(w, style = MaterialTheme.typography.bodyMedium, color = OnSurface)
                }
            }
        }
    }
}

@Composable
fun TechCard(techs: List<String>) {
    SectionCard("Technologies", Icons.Default.Code) {
        if (techs.isEmpty()) {
            Text("None detected", color = OnSurfaceDim, style = MaterialTheme.typography.bodyMedium)
        } else {
            FlowRow(techs)
        }
    }
}

@Composable
fun FlowRow(items: List<String>) {
    var rowItems = items
    Column {
        while (rowItems.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val batch = rowItems.take(3)
                rowItems = rowItems.drop(3)
                batch.forEach { item ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(SurfaceBright)
                            .border(1.dp, Outline, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(item, style = MaterialTheme.typography.labelSmall, color = ScannerBlue)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
fun LeaksCard(leaks: List<String>) {
    SectionCard("Secrets & Leaks", Icons.Default.Warning, iconTint = ScannerRed) {
        leaks.forEach { leak ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(ScannerRed.copy(alpha = 0.08f))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.ErrorOutline, null, tint = ScannerRed,
                    modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(8.dp))
                Text(leak, style = MaterialTheme.typography.bodySmall, color = ScannerRed)
            }
        }
    }
}

@Composable
fun SensitivePathsCard(paths: List<SensitivePath>) {
    SectionCard(
        "Sensitive Paths (${paths.size} found)",
        Icons.Default.FolderOpen,
        iconTint = if (paths.isEmpty()) ScannerGreen else ScannerOrange
    ) {
        if (paths.isEmpty()) {
            Text("No exposed sensitive paths found", color = ScannerGreen,
                style = MaterialTheme.typography.bodyMedium)
        } else {
            paths.forEach { path ->
                val color = when (path.statusCode) {
                    200 -> ScannerRed
                    403 -> ScannerOrange
                    else -> OnSurface
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        path.path,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = color,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    StatusBadge(path.note, color)
                }
            }
        }
    }
}

@Composable
fun CorsCard(cors: List<String>) {
    val hasIssues = cors.any { "wildcard" in it || "reflected" in it || "credentials" in it }
    SectionCard("CORS Policy", Icons.Default.SwapHoriz,
        iconTint = if (hasIssues) ScannerRed else ScannerGreen) {
        cors.forEach { finding ->
            val color = when {
                "wildcard" in finding || "credentials" in finding -> ScannerRed
                "reflected" in finding -> ScannerOrange
                else -> OnSurfaceDim
            }
            Text(" · $finding", style = MaterialTheme.typography.bodySmall, color = color)
        }
    }
}

@Composable
fun CookiesCard(issues: List<String>) {
    SectionCard("Cookie Security", Icons.Default.Cookie,
        iconTint = if (issues.isEmpty()) ScannerGreen else ScannerOrange) {
        if (issues.isEmpty()) {
            Text("No cookie issues found", color = ScannerGreen,
                style = MaterialTheme.typography.bodyMedium)
        } else {
            issues.forEach { issue ->
                Text(" · $issue", style = MaterialTheme.typography.bodySmall, color = ScannerOrange)
            }
        }
    }
}

@Composable
fun HttpMethodsCard(methods: List<String>) {
    val dangerous = methods.filter { it.startsWith("PUT") || it.startsWith("DELETE") || it.startsWith("PATCH") }
    SectionCard("HTTP Methods", Icons.Default.Http,
        iconTint = if (dangerous.isNotEmpty()) ScannerOrange else ScannerGreen) {
        if (methods.isEmpty()) {
            Text("None detected", color = OnSurfaceDim, style = MaterialTheme.typography.bodyMedium)
        } else {
            methods.forEach { method ->
                val isDangerous = method.startsWith("PUT") || method.startsWith("DELETE") ||
                        method.startsWith("PATCH") || method.startsWith("TRACE")
                val color = if (isDangerous) ScannerOrange else ScannerGreen
                Row(modifier = Modifier.padding(vertical = 2.dp)) {
                    StatusBadge(method, color)
                }
                Spacer(Modifier.width(4.dp))
            }
        }
    }
}

@Composable
fun DnsCard(records: Map<String, List<String>>, consistency: Map<String, List<String>>) {
    SectionCard("DNS Records", Icons.Default.Dns) {
        if (records.isEmpty()) {
            Text("No DNS records retrieved", color = OnSurfaceDim,
                style = MaterialTheme.typography.bodyMedium)
        } else {
            records.forEach { (type, values) ->
                if (values.isNotEmpty()) {
                    Text(type, style = MaterialTheme.typography.labelSmall, color = ScannerBlue)
                    values.forEach { v ->
                        Text("  $v", style = MaterialTheme.typography.bodySmall,
                            color = OnSurface, fontFamily = FontFamily.Monospace)
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }
        }
        if (consistency.isNotEmpty()) {
            Spacer(Modifier.height(6.dp))
            Divider(color = Outline)
            Spacer(Modifier.height(6.dp))
            Text("DNS consistency check:", style = MaterialTheme.typography.bodySmall, color = OnSurfaceDim)
            consistency.forEach { (server, ips) ->
                InfoRow(server, ips.joinToString(", "))
            }
        }
    }
}

@Composable
fun SubdomainsCard(subdomains: List<String>) {
    SectionCard("Subdomains (${subdomains.size})", Icons.Default.AccountTree, iconTint = ScannerPurple) {
        subdomains.take(20).forEach { sub ->
            Text(
                " · $sub",
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                color = ScannerPurple
            )
        }
        if (subdomains.size > 20)
            Text(" · +${subdomains.size - 20} more", style = MaterialTheme.typography.bodySmall,
                color = OnSurfaceDim)
    }
}

@Composable
fun PortsCard(ports: List<Int>) {
    val knownPorts = mapOf(
        21 to "FTP", 22 to "SSH", 23 to "Telnet", 25 to "SMTP", 53 to "DNS",
        80 to "HTTP", 443 to "HTTPS", 3306 to "MySQL", 3389 to "RDP",
        5432 to "PostgreSQL", 6379 to "Redis", 8080 to "HTTP-alt",
        8443 to "HTTPS-alt", 9200 to "Elasticsearch", 27017 to "MongoDB"
    )
    val dangerousPorts = setOf(21, 23, 3306, 3389, 5432, 6379, 9200, 27017)

    SectionCard("Open Ports (${ports.size})", Icons.Default.Router,
        iconTint = if (ports.any { it in dangerousPorts }) ScannerRed else ScannerOrange) {
        ports.forEach { port ->
            val isDangerous = port in dangerousPorts
            val color = if (isDangerous) ScannerRed else ScannerOrange
            val service = knownPorts[port] ?: "unknown"
            Row(
                modifier = Modifier.padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusBadge("$port/$service", color)
                if (isDangerous) {
                    Text("⚠ exposed", style = MaterialTheme.typography.labelSmall, color = ScannerRed)
                }
            }
        }
    }
}

@Composable
fun MiscCard(result: ScanResult) {
    SectionCard("Robots & Sitemap", Icons.Default.FindInPage) {
        InfoRow("robots.txt", result.robots,
            if (result.robots == "Found") ScannerGreen else OnSurfaceDim)
        InfoRow("sitemap.xml", result.sitemap,
            if (result.sitemap == "Found") ScannerGreen else OnSurfaceDim)
    }
}

@Composable
fun ErrorsCard(errors: List<String>) {
    SectionCard("Errors / Skipped", Icons.Default.BugReport, iconTint = ScannerRed) {
        errors.forEach { err ->
            Text(" · $err", style = MaterialTheme.typography.bodySmall, color = ScannerRed)
        }
    }
}
